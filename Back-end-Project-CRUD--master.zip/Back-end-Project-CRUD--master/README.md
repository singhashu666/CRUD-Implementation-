# Creating a rest API to implement CRUD opearations.

We are going  to build Backend REST API with CRUD operations
1. Firstly getting connected to the backend with MongoDB database.
2. Create a APIs to perform CRUD oprations on Database. Have a user table/collection and perform CRUD (Create,Read,Update & Delete ) Operations on database through  API.
3. Create a user list API with pagination.
